export class Funcionalidad {
    constructor(
        public id_funcionalidad: number,
        public nombre_funcionalidad: string,
        public Descripcion: string
    ){}
}