export class Rol {
    constructor(
        public id_rol: number,
        public nombre_rol: string,
        public descripcion: string
        ) { }

}