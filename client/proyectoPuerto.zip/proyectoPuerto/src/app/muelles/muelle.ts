export class Muelle {
    constructor(
        public id_muelle: number,
        public nombre_muelle: string,
        public descripcion: string,
        public ocupado: number
    ) { }
}